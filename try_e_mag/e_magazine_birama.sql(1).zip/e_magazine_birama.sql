-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Nov 01, 2014 at 05:21 AM
-- Server version: 5.0.41
-- PHP Version: 5.2.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `e_magazine_birama`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `admin`
-- 

CREATE TABLE `admin` (
  `username_admin` varchar(800) collate latin1_general_ci NOT NULL,
  `pass_admin` varchar(800) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`username_admin`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Dumping data for table `admin`
-- 

INSERT INTO `admin` VALUES ('it_team_birama_2014', 'jakapratamaif');

-- --------------------------------------------------------

-- 
-- Table structure for table `artikel_news`
-- 

CREATE TABLE `artikel_news` (
  `id_news` int(90) NOT NULL auto_increment,
  `judul_berita_news` text collate latin1_general_ci NOT NULL,
  `sinopsis_berita_news` text collate latin1_general_ci NOT NULL,
  `isi_berita_news` text collate latin1_general_ci NOT NULL,
  `foto_news` varchar(500) collate latin1_general_ci NOT NULL,
  `kategori` varchar(300) collate latin1_general_ci NOT NULL,
  `penerbit` varchar(800) collate latin1_general_ci NOT NULL,
  `link_news` varchar(450) collate latin1_general_ci NOT NULL,
  `tanggal_post` datetime NOT NULL,
  PRIMARY KEY  (`id_news`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=40 ;

-- 
-- Dumping data for table `artikel_news`
-- 

INSERT INTO `artikel_news` VALUES (38, 'saya bangga menjadi anak indonesia', 'jskhgkjshdgkjhsjgkhsdhjskhgkjshdgkjhsjgkhsdhjskhgkjshdgkjhsjgkhsdhjskhgkjshdgkjhsjgkhsdhjskhgkjshdgkjhsjgkhsdhjskhgkjshdgkjhsjgkhsdhjskhgkjshdgkjhsjgkhsdhjskhgkjshdgkjhsjgkhsdhjskhgkjshdgkjhsjgkhsdhjskhgkjshdgkjhsjgkhsdhjskhgkjshdgkjhsjgkhsdhjskhgkjshdgkjhsjgkhsdhjskhgkjshdgkjhsjgkhsdhjskhgkjshdgkjhsjgkhsdh', 'kajdgl', 'Tulips.jpg', 'Community Zone', 'HIMA IF', 'http://www.ganool.com/dl', '2014-10-31 07:54:21');
INSERT INTO `artikel_news` VALUES (37, 'selamat pagi kota bandung', 'jaklsjgkajgljakjsglajkjglajdkglajklhjkladjkhaljdkhljakldjkaljklhdajkhldajkhjaljdjal.jdhfkjkhsjlfjhlskjf.hjsdfjkhlksdfjhl.jskdflhskldfjhsjlfjkhlsjdfk..hljfdl.j.hlsjfdljh.jsfhlsjdfkhjskldjhklsjkdfjhlsjkhfsjhklfjlk.hkjsdfh.sjfdkhkjsdfl', 'gdsgsjdhgksh', 'Jellyfish.jpg', 'Biografi', 'HIMA IF', 'http://www.ganool.com/dl', '2014-10-31 07:52:26');
INSERT INTO `artikel_news` VALUES (39, 'selamat datang di e-magazine birama', 'asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj ', 'asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj asjfjaklsjfklajsghj ', 'Koala.jpg', 'Unikom Activities', 'HIMA TK', 'http://www.4shared.com', '2014-11-01 03:48:58');
