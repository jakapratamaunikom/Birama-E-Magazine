-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Oct 27, 2014 at 10:38 AM
-- Server version: 5.0.41
-- PHP Version: 5.2.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `e_magazine_birama`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `artikel_news`
-- 

CREATE TABLE `artikel_news` (
  `id_news` int(90) NOT NULL auto_increment,
  `judul_berita_news` text collate latin1_general_ci NOT NULL,
  `sinopsis_berita_news` text collate latin1_general_ci NOT NULL,
  `isi_berita_news` text collate latin1_general_ci NOT NULL,
  `foto_news` varchar(500) collate latin1_general_ci NOT NULL,
  `kategori` varchar(300) collate latin1_general_ci NOT NULL,
  `link_news` varchar(450) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_news`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=34 ;

-- 
-- Dumping data for table `artikel_news`
-- 

INSERT INTO `artikel_news` VALUES (33, 'bep kita nikah yu', 'ksdjkjshg', 'hjksdjkgh', 'Koala.jpg', 'Biografi', 'sjgklj');
INSERT INTO `artikel_news` VALUES (32, 'uus', 'ksdjl', 'kldjlsk', 'Lighthouse.jpg', 'Hima', 'asjflgk');
INSERT INTO `artikel_news` VALUES (31, 'usus buntu', 'jskdhgsj', 'khjdkhsgk', '', 'Komunitas_Unikom', 'http://www.facebool.com');
INSERT INTO `artikel_news` VALUES (30, 'biopori', 'jksjflajg', 'mskldgj', '', 'Komik', '239723');
INSERT INTO `artikel_news` VALUES (29, 'bismilah', 'bismilah', 'bismilah', '', 'Cerpen', 'bismilah');
INSERT INTO `artikel_news` VALUES (28, 'jaka', 'jakjk', 'jdksjgk', '', 'Komunitas_Unikom', 'kjdhgkshd');
INSERT INTO `artikel_news` VALUES (27, 'jakjfksaj', 'jashkfdsf', 'sjdhgksjh', '', 'News', 'gfgf');
INSERT INTO `artikel_news` VALUES (26, 'uuu', 'njsfj', 'jhdsghjs', '', 'Komunitas_Unikom', 'sdgsd');
INSERT INTO `artikel_news` VALUES (25, 'haseum', 'jdksjfk', 'jkjdksjg', '', 'Komunitas_Unikom', 'afsaf');
