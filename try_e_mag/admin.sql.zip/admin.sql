-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Oct 27, 2014 at 10:38 AM
-- Server version: 5.0.41
-- PHP Version: 5.2.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `e_magazine_birama`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `admin`
-- 

CREATE TABLE `admin` (
  `username_admin` varchar(800) collate latin1_general_ci NOT NULL,
  `pass_admin` varchar(800) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`username_admin`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Dumping data for table `admin`
-- 

INSERT INTO `admin` VALUES ('it_team_birama_2014', 'jakapratamaif');
